package com.yesu.insuranceProject.controllers;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.yesu.insuranceProject.contracts.InsuranceInterfaceRepository;
import com.yesu.insuranceProject.models.NetworkHospitals;

@RestController
public class InsuranceController {

	@Autowired
	InsuranceInterfaceRepository insrip;

	@GetMapping(value = "/networkhospitals")
	public ArrayList<NetworkHospitals> getHospitals() {
		ArrayList<NetworkHospitals> list = (ArrayList<NetworkHospitals>) insrip.getHospitals();
		return list;
	}

	@PostMapping(value = "/addNetworkHospitalData")
	public ResponseEntity<String> addHospital(@RequestBody NetworkHospitals networkHospital) {
		try {
			// Here, 'networkHospital' is automatically populated with the JSON data from the request body
			insrip.insertRowData(networkHospital);

			System.out.println(networkHospital.getHosp_id());

			return ResponseEntity.ok("Hospital added successfully" + networkHospital);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error adding hospital");
		}
	}

	@PutMapping("/updateNetworkHospital")
	public ResponseEntity<String> updateHospitalData(@RequestBody Map<String, Object> requestData) {
		try {
			// Extract the data from the JSON request
			String id = (String) requestData.get("id");
			String hospPhone = (String) requestData.get("hosp_phone");
			String hospTitle = (String) requestData.get("hosp_title");
			String hospLocation = (String) requestData.get("hosp_location");
			String hospAddress = (String) requestData.get("hosp_address");

			insrip.updateRowById(Integer.parseInt(id), hospPhone, hospTitle, hospLocation, hospAddress);

			System.out.println(id + "IDDD");
			// Your code to update the hospital data based on the provided fields
			// You can use the 'id' to identify the specific hospital record and update its fields

			// Assuming a successful update, return a success response
			return ResponseEntity.ok("Hospital data updated successfully");
		} catch (Exception e) {
			// Handle any exceptions that may occur during the update
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error updating hospital data: " + e.getMessage());
		}
	}

}
