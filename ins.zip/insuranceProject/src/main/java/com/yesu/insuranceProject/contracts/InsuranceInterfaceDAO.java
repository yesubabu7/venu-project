package com.yesu.insuranceProject.contracts;

import java.util.List;

import com.yesu.insuranceProject.models.NetworkHospitals;

public interface InsuranceInterfaceDAO {

	List<NetworkHospitals> getHospitals();

	void insertRowData(NetworkHospitals networkHospital);

	void updateRowTodao(int id, String hospPhone, String hospTitle, String hospLocation, String hospAddress);

}