package com.yesu.insuranceProject.contracts;

import java.util.List;

import com.yesu.insuranceProject.models.NetworkHospitals;

public interface InsuranceInterfaceRepository {

	List<NetworkHospitals> getHospitals();

	void insertRowData(NetworkHospitals networkHospital);

	void updateRowById(int parseInt, String hospPhone, String hospTitle, String hospLocation, String hospAddress);

}
