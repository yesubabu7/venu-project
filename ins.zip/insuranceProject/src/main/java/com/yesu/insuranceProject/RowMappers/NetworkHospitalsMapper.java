package com.yesu.insuranceProject.RowMappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yesu.insuranceProject.models.NetworkHospitals;

public class NetworkHospitalsMapper implements RowMapper<NetworkHospitals> {

	@Override
	public NetworkHospitals mapRow(ResultSet rs, int rowNum) throws SQLException {
		NetworkHospitals dd = new NetworkHospitals();
		dd.setHosp_id(rs.getInt(1));
		dd.setHosp_title(rs.getString(2));
		dd.setHosp_location(rs.getString(3));
		dd.setHosp_address(rs.getString(4));
		dd.setHosp_phone(rs.getLong(5));
		dd.setHosp_mobile(rs.getLong(6));
		dd.setHosp_pincode(rs.getInt(7));
		dd.setHosp_luudate(rs.getDate(8));
		dd.setHosp_luuser(rs.getInt(9));

		return dd;

	}

}