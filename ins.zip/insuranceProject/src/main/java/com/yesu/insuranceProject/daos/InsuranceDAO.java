package com.yesu.insuranceProject.daos;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.yesu.insuranceProject.RowMappers.NetworkHospitalsMapper;
import com.yesu.insuranceProject.contracts.InsuranceInterfaceDAO;
import com.yesu.insuranceProject.models.NetworkHospitals;

@Component
public class InsuranceDAO implements InsuranceInterfaceDAO {

	JdbcTemplate jdbcTemplate;

	private String SQL_GET_HOSPITALS = "select * from varshu_network_hospitals";

	@Autowired
	public InsuranceDAO(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<NetworkHospitals> getHospitals() {

		return jdbcTemplate.query(SQL_GET_HOSPITALS, new NetworkHospitalsMapper());
	}

	@Override
	public void insertRowData(NetworkHospitals networkHospital) {
		// Define your SQL INSERT query
		String sql = "INSERT INTO yesu_Hospitals (hosp_id, hosp_title, hosp_location, hosp_address, "
				+ "hosp_phone, hosp_mobile, hosp_pincode, hosp_luudate, hosp_luuser) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try {
			// Execute the SQL query with the provided data
			jdbcTemplate.update(sql, networkHospital.getHosp_id(), networkHospital.getHosp_title(),
					networkHospital.getHosp_location(), networkHospital.getHosp_address(),
					networkHospital.getHosp_phone(), networkHospital.getHosp_mobile(),
					networkHospital.getHosp_pincode(), networkHospital.getHosp_luudate(),
					networkHospital.getHosp_luuser());
		} catch (Exception e) {
			// Handle any exceptions here
			e.printStackTrace();
		}
	}

	@Override
	public void updateRowTodao(int id, String hospPhone, String hospTitle, String hospLocation, String hospAddress) {
		// TODO Auto-generated method stub
		long hosp_phone = Long.parseLong(hospPhone); // Parse as a long
		String sql = "UPDATE yesu_Hospitals "
				+ "SET hosp_phone = ?, hosp_title = ?, hosp_location = ?, hosp_address = ? " + "WHERE hosp_id = ?";

		jdbcTemplate.update(sql, hosp_phone, hospTitle, hospLocation, hospAddress, id);

	}
}