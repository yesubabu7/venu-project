package com.yesu.insuranceProject.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yesu.insuranceProject.contracts.InsuranceInterfaceDAO;
import com.yesu.insuranceProject.contracts.InsuranceInterfaceRepository;
import com.yesu.insuranceProject.models.NetworkHospitals;

@Repository
class InsuranceRepository implements InsuranceInterfaceRepository {

	@Autowired
	InsuranceInterfaceDAO insurancedao;

	@Override
	public List<NetworkHospitals> getHospitals() {
		List<NetworkHospitals> list1 = insurancedao.getHospitals();
		return list1;
	}

	@Override
	public void insertRowData(NetworkHospitals networkHospital) {
		insurancedao.insertRowData(networkHospital);

	}

	public void updateRowById(int id, String hospPhone, String hospTitle, String hospLocation, String hospAddress) {
		// TODO Auto-generated method stub
		insurancedao.updateRowTodao(id, hospPhone, hospTitle, hospLocation, hospAddress);

	}

}
